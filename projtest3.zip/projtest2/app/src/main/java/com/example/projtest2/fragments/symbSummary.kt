package com.example.projtest2.fragments

data class symbSummary(
    val change_percent: Double,
    val current_price: Double,
    val logo_url: String,
    val symbol: String
)