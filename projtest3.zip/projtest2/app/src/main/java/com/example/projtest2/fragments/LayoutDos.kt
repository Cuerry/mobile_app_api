package com.example.projtest2.fragments

import android.os.Bundle
import android.widget.Adapter
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.projtest2.R
import org.w3c.dom.Comment
import android.os.BaseBundle
import androidx.appcompat.app.AppCompatActivity
import com.example.projtest2.fragments.CustomAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit

import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.converter.gson.GsonConverterFactory

class LayoutDos: Fragment() {

    private val BASE_URL = "https://tuxdroid.pythonanywhere.com/"
    private val TAG: String = "CHECK_RESPONSE"
    private lateinit var recyclerViewNews: RecyclerView
    private lateinit var newsAdapter: CustomAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_dos, container, false)
        recyclerViewNews = view.findViewById(R.id.rvTodos)
        recyclerViewNews.layoutManager = LinearLayoutManager(requireContext())
        newsAdapter = CustomAdapter(emptyList())
        recyclerViewNews.adapter = newsAdapter

        val dummyData = listOf(
            news("2023-01-01", "Dummy Description", "https://picsum.photos/200/300", "Dummy Title")
        )
        newsAdapter.updateData(dummyData)


        getAllComments()
        return view
    }

    

    private fun getAllComments(){
        val api = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(MyApi::class.java)



        api.getPosts().enqueue(object  : Callback<List<news>>{

            override fun onResponse(call: Call<List<news>>, response: Response<List<news>>) {

                if (response.isSuccessful){
                    response.body()?.let {
                        response.body()?.let { newsList ->
                            // Update the adapter data with the list of news items
                            newsAdapter.updateData(newsList)
                            Log.i(TAG, "onResponse: ${newsList.size} items received")
                        }
                    }

                }
            }


            override fun onFailure(call: Call<List<news>>, t: Throwable) {
                Log.i(TAG, "onFailure: ${t.message}")
            }

        })
    }


}
