package com.example.projtest2.fragments

data class Details(
    val change_percent: Double,
    val current_price: Double
)