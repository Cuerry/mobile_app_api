package com.example.projtest2.fragments

data class ChartData(
    val October_2022: List<Double>
)