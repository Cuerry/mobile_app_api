package com.example.projtest2.fragments

data class symbDetails(
    val CEO: String,
    val chart_data: ChartData,
    val description: String,
    val details: Details,
    val logo_url: String,
    val sector: String,
    val symbol: String
)