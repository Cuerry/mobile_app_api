package com.example.projtest2.fragments

import retrofit2.http.Url

data class todo(val date: String,
                val description: String,
                val image_url: Url,
                val title: String)
