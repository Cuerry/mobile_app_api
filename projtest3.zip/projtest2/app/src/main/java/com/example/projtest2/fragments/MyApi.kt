package com.example.projtest2.fragments

import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface MyApi {

    @GET("api/news")
    fun getPosts(): Call<List<news>>

    @GET("api/symbols")
    fun getsymb(): Call<List<symbols>>

    @GET("api/symbol/summary/{symbol}")
    fun getsum(): Call<List<symbSummary>>

    @GET("api/symbol/details/{symbol}")
    fun getdet(): Call<List<symbDetails>>

}