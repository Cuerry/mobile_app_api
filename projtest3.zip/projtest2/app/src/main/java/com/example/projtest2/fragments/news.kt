package com.example.projtest2.fragments

import android.widget.ImageView
import retrofit2.http.Url
import java.net.URL

data class news(
    val date: String,
    val description: String,
    val image_url: String,
    val title: String
)