package com.example.projtest2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.projtest2.fragments.LayoutFragment
import android.util.Log
import com.example.projtest2.fragments.MyApi
import com.example.projtest2.fragments.todo
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_screen)


        if (savedInstanceState != null) {
            supportFragmentManager.beginTransaction()
                .add(R.id.fragment_container, LayoutFragment())
                .commit()
        }

    }

}



