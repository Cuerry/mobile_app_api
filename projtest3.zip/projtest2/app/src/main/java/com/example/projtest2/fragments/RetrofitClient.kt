package com.example.projtest2.fragments

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    val api: todo by lazy {
        Retrofit.Builder()
            .baseUrl("https://tuxdroid.pythonanywhere.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(todo::class.java)
    }
}