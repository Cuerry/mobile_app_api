package com.example.projtest2.fragments

import android.view.LayoutInflater
import retrofit2.http.Url
import android.view.View
import android.view.ViewGroup
import com.squareup.picasso.Picasso
import android.widget.ImageView

import android.widget.TextClock
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.example.projtest2.R

internal class CustomAdapter(
    var todos: List<news>
) : RecyclerView.Adapter<CustomAdapter.todoviewholder>(){



    internal class todoviewholder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val titulo: TextView = itemView.findViewById(R.id.titulo)
        val descricao: TextView = itemView.findViewById(R.id.descricao)
        val data: TextView = itemView.findViewById(R.id.data)
        val image: ImageView = itemView.findViewById(R.id.imageView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): todoviewholder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item, parent, false)
        return todoviewholder(view)
    }
    fun updateData(newNewsList: List<news>) {
        todos = newNewsList
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return todos.size
    }

    override fun onBindViewHolder(holder: todoviewholder, position: Int) {
        val currentNews = todos[position]

        holder.titulo.text = currentNews.title
        holder.data.text = currentNews.date
        holder.descricao.text = currentNews.description

        Picasso.get().load(currentNews.image_url).into(holder.image)
    }
}
