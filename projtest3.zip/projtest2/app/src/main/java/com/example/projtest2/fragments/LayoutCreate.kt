package com.example.projtest2.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.example.projtest2.R
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class LayoutCreate: Fragment() {

    private val BASE_URL = "https://tuxdroid.pythonanywhere.com/"
    private val TAG: String = "CHECK_RESPONSE"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        getAllComments()
        return inflater.inflate(R.layout.fragment_creat, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<Button>(R.id.button6).setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerView2, LayoutPrincipal())
                .addToBackStack(null)
                .commit()
        }

    }

    private fun getAllComments(){
        val api = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(MyApi::class.java)

        api.getsymb().enqueue(object  : Callback<List<symbols>> {
            override fun onResponse(call: Call<List<symbols>>, response: Response<List<symbols>>) {
                if (response.isSuccessful){
                    response.body()?.let {
                        for(symbols in it){
                            Log.i(TAG,"onResponse: ${symbols.symba}")
                        }
                    }
                }
            }

            override fun onFailure(call: Call<List<symbols>>, t: Throwable) {
                Log.i(TAG, "onFailure: ${t.message}")
            }

        })
    }

}