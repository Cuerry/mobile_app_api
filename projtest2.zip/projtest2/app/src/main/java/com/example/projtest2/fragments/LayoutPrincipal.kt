package com.example.projtest2.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.example.projtest2.R

class LayoutPrincipal: Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(
            R.layout.fragmen_pric,
            container,
            false
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<Button>(R.id.button4).setOnClickListener{
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerView,LayoutDos())
                .addToBackStack(null)
                .commit()
        }

        view.findViewById<Button>(R.id.button2).setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerView,LayoutFragment())
                .addToBackStack(null)
                .commit()
        }

        view.findViewById<Button>(R.id.button).setOnClickListener{
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerView2,LayoutCreate())
                .addToBackStack(null)
                .commit()
        }
    }

    /*override fun onView(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<Button>(R.id.button2).setOnClickListener {
            parentFragmentManager.popBackStack()
        }
    }*/
}