package com.example.projtest2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.projtest2.fragments.LayoutFragment

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_screen)
        
        if(savedInstanceState != null){
            supportFragmentManager.beginTransaction()
                .add(R.id.fragment_container,LayoutFragment())
                .commit()
        }
    }
}

